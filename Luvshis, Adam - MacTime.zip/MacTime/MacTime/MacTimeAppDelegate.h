//
//  MacTimeAppDelegate.h
//  MacTime
//
//  Created by Adam Luvshis on 4/29/13.
//  Copyright (c) 2013 Rochester Institute of Technology. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MacTimeViewController.h"

@interface MacTimeAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
