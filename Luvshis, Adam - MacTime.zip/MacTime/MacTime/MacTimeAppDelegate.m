//
//  MacTimeAppDelegate.m
//  MacTime
//
//  Created by Adam Luvshis on 4/29/13.
//  Copyright (c) 2013 Rochester Institute of Technology. All rights reserved.
//

#import "MacTimeAppDelegate.h"
#import <OpenDirectory/OpenDirectory.h>

@implementation MacTimeAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
    
}

@end
