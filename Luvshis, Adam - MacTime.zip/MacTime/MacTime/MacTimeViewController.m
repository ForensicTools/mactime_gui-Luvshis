//
//  MacTimeViewController.m
//  MacTime
//
//  Created by Adam Luvshis on 4/29/13.
//  Copyright (c) 2013 Rochester Institute of Technology. All rights reserved.
//

#import "MacTimeViewController.h"

@implementation MacTimeViewController

- (IBAction)runArguments:(id)sender {
    NSLog(@"Info = %@", bodyFileName);
    if([version state] == 1) {
        NSTask *getVersion = [[NSTask alloc] init];
        NSPipe *versionPipe = [NSPipe pipe];
        NSArray *arguments = [NSArray arrayWithObjects:@"-V", nil];
        NSPipe *errorPipe = [NSPipe pipe];
        NSFileHandle* errorReader = [errorPipe fileHandleForReading];
        [getVersion setLaunchPath:@"/opt/local/bin/mactime"];
        [getVersion setArguments:arguments];
        [getVersion setStandardOutput:versionPipe];
        [getVersion setStandardError:errorPipe];
        [getVersion launch];
        [getVersion waitUntilExit];
        
        
        NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
        
        NSFileHandle *file = [versionPipe fileHandleForReading];
        NSData *data = [file readDataToEndOfFile];
        NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
        //NSLog(@"Output = %@",response);

        [versionOutput setStringValue:response];
    }
    if([bodyFile state] == 1) {
        if(![bodyFileName isEqualToString:NULL]) {
            [self setDateTime];
            [self setSize];
            [self setActivityType];
            [self setUnixPermissions];
            [self setUID];
            [self setGID];
            [self setInode];
            [self setFilenames];
        }
        else {
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Body file was not provided."];
            [alert setAlertStyle:NSWarningAlertStyle];
            [alert runModal];
        }
    }
    if([isoFormat state]==1 && [bodyFile state] == 1) {
        if(![bodyFileName isEqualToString:NULL]) {
            [self setISODateTime];
            [self setSize];
            [self setActivityType];
            [self setUnixPermissions];
            [self setUID];
            [self setGID];
            [self setInode];
            [self setFilenames];
        }
        else {
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Body file was not provided."];
            [alert setAlertStyle:NSWarningAlertStyle];
            [alert runModal];
        }
    }
    if([monthNo state]==1 && [bodyFile state] == 1) {
        if(![bodyFileName isEqualToString:NULL]) {
            [self setMoNODateTime];
            [self setSize];
            [self setActivityType];
            [self setUnixPermissions];
            [self setUID];
            [self setGID];
            [self setInode];
            [self setFilenames];
        }
        else {
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Body file was not provided."];
            [alert setAlertStyle:NSWarningAlertStyle];
            [alert runModal];
        }
    }
    if([monthNo state]==1 && [bodyFile state] != 1) {
        if(![bodyFileName isEqualToString:NULL]) {
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Please make sure the -b argument is checked."];
            [alert setAlertStyle:NSWarningAlertStyle];
            [alert runModal];
        }
    }
    if([isoFormat state]==1 && [bodyFile state] != 1) {
        if(![bodyFileName isEqualToString:NULL]) {
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Please make sure the -b argument is checked."];
            [alert setAlertStyle:NSWarningAlertStyle];
            [alert runModal];
        }
    }
    if([bodyFile state] == 0 && [isoFormat state] == 0 && [monthNo state] == 0 && [version state] == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No arguments were selected."];
        [alert setAlertStyle:NSWarningAlertStyle];
        [alert runModal];
    }
}

- (void)setMoNODateTime {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-m", @"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-f", @"1-5", @"-d", @" ", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [dateTime setString:response];
}

- (void)setISODateTime {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-y", @"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-f", @"1-5", @"-d", @" ", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [dateTime setString:response];
}

- (void)setDateTime {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-f", @"1-5", @"-d", @" ", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [dateTime setString:response];
}

- (void)setSize {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"29-34", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [size setString:response];
}

- (void)setActivityType {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"35-39", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [activityType setString:response];
}

- (void)setUnixPermissions {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"40-52", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [permissions setString:response];
}

- (void)setUID {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"53-61", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [uid setString:response];
}

- (void)setGID {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"62-70", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [gid setString:response];
}

- (void)setInode {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"71-79", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [inode setString:response];
}

- (void)setFilenames {
    NSTask *bodyTask = [[NSTask alloc] init];
    NSPipe *bodyPipe = [NSPipe pipe];
    NSArray *arguments = [NSArray arrayWithObjects:@"-b", bodyFileName, nil];
    NSPipe *errorPipe = [NSPipe pipe];
    [bodyTask setLaunchPath:@"/opt/local/bin/mactime"];
    [bodyTask  setArguments:arguments];
    [bodyTask  setStandardOutput:bodyPipe];
    [bodyTask  setStandardError:errorPipe];
    [bodyTask  launch];
    [bodyTask  waitUntilExit];
    
    NSTask *grabOutput = [[NSTask alloc] init];
    NSPipe *outputPipe = [NSPipe pipe];
    NSArray *arguments2 = [NSArray arrayWithObjects:@"-c", @"80-", nil];
    NSPipe *errorPipe2 = [NSPipe pipe];
    NSFileHandle *errorReader = [errorPipe2 fileHandleForReading];
    [grabOutput setLaunchPath:@"/usr/bin/cut"];
    [grabOutput setArguments:arguments2];
    [grabOutput setStandardInput:bodyPipe];
    [grabOutput setStandardOutput:outputPipe];
    [grabOutput setStandardError:errorPipe2];
    [grabOutput launch];
    [grabOutput waitUntilExit];
    
    NSString *errorString = [[NSString alloc] initWithData:[errorReader readDataToEndOfFile] encoding:NSUTF8StringEncoding];
    
    NSFileHandle *file = [outputPipe fileHandleForReading];
    NSData *data = [file readDataToEndOfFile];
    NSString *response = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
    
    [filename setString:response];
}

- (IBAction)disableArguments:(id)sender {
    if([version state] == 1) {
        [bodyFile setEnabled:0];
        [bodyFile setState:0];
        [isoFormat setEnabled:0];
        [isoFormat setState:0];
        [monthNo setEnabled:0];
        [monthNo setState:0];
        
    }
    else if([version state] == 0) {
        [bodyFile setEnabled:1];
        [isoFormat setEnabled:1];
        [monthNo setEnabled:1];
    }
}

- (IBAction)disableYArgument:(id)sender {
    if([monthNo state] == 1) {
        [isoFormat setEnabled:0];
        [isoFormat setState:0];
    }
    else if([monthNo state] == 0) {
        [isoFormat setEnabled:1];
    }
}

- (IBAction)disableMArgument:(id)sender {
    if([isoFormat state] == 1) {
        [monthNo setEnabled:0];
        [monthNo setState:0];
    }
    else if([isoFormat state] == 0) {
        [monthNo setEnabled:1];
    }
}

- (IBAction)selectBodyFile:(id)sender{
 
    NSOpenPanel* openDlg = [NSOpenPanel openPanel];
 
    // Enable the selection of files in the dialog.
    [openDlg setCanChooseFiles:YES];
 
    // Enable the selection of directories in the dialog.
    [openDlg setCanChooseDirectories:YES];
    
    // Display the dialog.  If the OK button was pressed,
    // process the files.
    if ([openDlg runModalForDirectory:nil file:nil] == NSOKButton )
    {
        // Get an array containing the full filenames of all
        // files and directories selected.
        NSArray* files = [openDlg filenames];
 
        // Loop through all the files and process them.
        for( int i = 0; i < [files count]; i++ )
        {
            NSString* fileName = [files objectAtIndex:i];
            bodyFileName = fileName;
        }
    }
    
    [bodyFileLocation setStringValue:bodyFileName];
}

@end
