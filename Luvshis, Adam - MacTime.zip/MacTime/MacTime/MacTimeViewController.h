//
//  MacTimeViewController.h
//  MacTime
//
//  Created by Adam Luvshis on 4/29/13.
//  Copyright (c) 2013 Rochester Institute of Technology. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MacTimeViewController : NSObject <NSApplicationDelegate> {
    IBOutlet NSButton *version;
    IBOutlet NSButton *bodyFile;
    IBOutlet NSButton *isoFormat;
    IBOutlet NSButton *monthNo;
    
    IBOutlet NSTextField *versionOutput;
    IBOutlet NSTextField *bodyFileLocation;
    
    IBOutlet NSTextView *dateTime;
    IBOutlet NSTextView *size;
    IBOutlet NSTextView *activityType;
    IBOutlet NSTextView *permissions;
    IBOutlet NSTextView *uid;
    IBOutlet NSTextView *gid;
    IBOutlet NSTextView *inode;
    IBOutlet NSTextView *filename;
    
    NSString *bodyFileName;
}

- (IBAction)runArguments:(id)sender;
- (IBAction)disableArguments:(id)sender;
- (IBAction)disableYArgument:(id)sender;
- (IBAction)disableMArgument:(id)sender;
- (IBAction)selectBodyFile:(id)sender;

@end
